const isPar = (nro:number) => nro % 2 == 0 ? true : false;

console.log('Res:', isPar(3));